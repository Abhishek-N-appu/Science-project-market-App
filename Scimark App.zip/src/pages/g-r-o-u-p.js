import { Button } from "@mui/material";
import { Link } from "react-router-dom";
import GroupIcon from "../components/group-icon";
import GroupComponent5 from "../components/group-component5";
import styles from "./g-r-o-u-p.module.css";

const GROUP = () => {
  return (
    <div className={styles.group}>
      <div className={styles.technology}>
        <img className={styles.image2Icon} alt="" src="/image-21@2x.png" />
        <GroupIcon />
        <div className={styles.technologyChild} />
        <b className={styles.yourGroups}>YOUR GROUPS..</b>
        <div className={styles.rectangleParent}>
          <div className={styles.groupChild} />
          <div className={styles.groupItem} />
          <div className={styles.groupInner} />
          <div className={styles.ellipseDiv} />
          <input className={styles.rectangleInput} type="file" />
          <b className={styles.group1}>GROUP1</b>
          <div className={styles.rectangleDiv} />
          <b className={styles.group2}>GROUP2</b>
          <div className={styles.groupChild1} />
          <b className={styles.group3}>GROUP3</b>
          <div className={styles.groupChild2} />
          <div className={styles.groupChild3} />
          <b className={styles.member1}>MEMBER 1</b>
          <Button
            className={styles.rectangleButton}
            sx={{ width: 175 }}
            color="primary"
            variant="contained"
          >
            create
          </Button>
          <div className={styles.groupChild4} />
          <Link className={styles.you} to="/you">
            YOU
          </Link>
          <div className={styles.groupChild5} />
          <b className={styles.member2}>MEMBER 2</b>
          <img className={styles.vectorIcon} alt="" src="/vector4.svg" />
          <img className={styles.vectorIcon1} alt="" src="/vector5.svg" />
          <img className={styles.clipIcon} alt="" src="/clip.svg" />
          <img className={styles.vectorIcon2} alt="" src="/vector6.svg" />
        </div>
        <Button
          className={styles.technologyItem}
          sx={{ width: 121 }}
          color="secondary"
          variant="contained"
        >
          Join
        </Button>
      </div>
      <GroupComponent5
        vector="/vector.svg"
        vector1="/vector1.svg"
        vector2="/vector2.svg"
        vector3="/vector3.svg"
        yOUTop="92.25%"
        yOULeft="0%"
        yOUWidth="100%"
        yOUHeight="7.75%"
        yOURight="0%"
        yOUBottom="0%"
        propTop="65.34%"
        propCursor="pointer"
        propTextDecoration="none"
        propHeight="49.77%"
        propTop1="15.76%"
        propBottom="34.48%"
        propTop2="69.42%"
        propHeight1="31.42%"
        propTop3="23.91%"
        propBottom1="44.67%"
        propHeight2="47.17%"
        propTop4="15.76%"
        propBottom2="37.07%"
        propTop5="65.34%"
        propHeight3="49.77%"
        propTop6="14.55%"
        propBottom3="35.68%"
        propTop7="65.34%"
        propCursor1="unset"
      />
    </div>
  );
};

export default GROUP;
