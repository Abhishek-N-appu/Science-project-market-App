import { Button } from "@mui/material";
import FormContainer from "../components/form-container";
import CreditCardForm from "../components/credit-card-form";
import GroupComponent5 from "../components/group-component5";
import styles from "./p-a-y-m-e-n-t.module.css";

const PAYMENT = () => {
  return (
    <div className={styles.payment}>
      <div className={styles.payment1}>
        <img className={styles.image2Icon} alt="" src="/image-23@2x.png" />
        <div className={styles.rectangleParent}>
          <div className={styles.groupChild} />
          <b className={styles.paymentMethods}>{`<-PAYMENT METHODS..`}</b>
        </div>
        <Button
          className={styles.paymentChild}
          sx={{ width: 237 }}
          color="primary"
          variant="contained"
          href="/after-pay"
        >
          PAY
        </Button>
        <div className={styles.rectangleGroup}>
          <div className={styles.groupItem} />
          <div className={styles.amountToBe}>Amount to be paid</div>
          <b className={styles.xyz}>XYZ</b>
        </div>
        <b className={styles.upi}>UPI</b>
        <FormContainer />
        <b className={styles.creditdebitCard}>CREDIT/DEBIT CARD</b>
        <CreditCardForm />
        <GroupComponent5
          vector="/vector9.svg"
          vector1="/vector10.svg"
          vector2="/vector11.svg"
          vector3="/vector12.svg"
          yOUTop="95.65%"
          yOULeft="0%"
          yOUWidth="100%"
          yOUHeight="4.11%"
          yOURight="0%"
          yOUBottom="0.24%"
          propTop="65.35%"
          propCursor="pointer"
          propTextDecoration="none"
          propHeight="49.81%"
          propTop1="15.8%"
          propBottom="34.39%"
          propTop2="69.43%"
          propHeight1="31.46%"
          propTop3="23.95%"
          propBottom1="44.59%"
          propHeight2="47.13%"
          propTop4="15.8%"
          propBottom2="37.07%"
          propTop5="65.35%"
          propHeight3="49.81%"
          propTop6="14.52%"
          propBottom3="35.67%"
          propTop7="65.35%"
          propCursor1="unset"
        />
      </div>
    </div>
  );
};

export default PAYMENT;
