import { useState } from "react";
import {
  TextField,
  InputAdornment,
  Icon,
  IconButton,
  Button,
} from "@mui/material";
import styles from "./r-e-g-i-s-t-e-r.module.css";

const REGISTER = () => {
  const [showPassword, setShowPassword] = useState(false);
  const handleShowPasswordClick = () => {
    setShowPassword(!showPassword);
  };
  return (
    <div className={styles.register}>
      <div className={styles.register1}>
        <img className={styles.image2Icon} alt="" src="/image-2@2x.png" />
        <b className={styles.welcomeOnboard}>Welcome Onboard</b>
        <div className={styles.letsHelpYou}>
          Let’s help you to reach your dream project
        </div>
        <div className={styles.registerChild} />
        <img className={styles.registerItem} alt="" src="/ellipse-1@2x.png" />
        <TextField
          className={styles.registerInner}
          color="error"
          label="Enter your name"
          sx={{ width: 237 }}
          variant="outlined"
        />
        <TextField
          className={styles.rectangleTextfield}
          color="success"
          name="email"
          id="email"
          label="Enter your email"
          required={true}
          sx={{ width: 237 }}
          variant="outlined"
          type="email"
        />
        <TextField
          className={styles.registerChild1}
          color="error"
          id="password"
          label="Enter password"
          required={true}
          sx={{ width: 237 }}
          variant="outlined"
          type={showPassword ? "text" : "password"}
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton
                  onClick={handleShowPasswordClick}
                  aria-label="toggle password visibility"
                >
                  <Icon>{showPassword ? "visibility_off" : "visibility"}</Icon>
                </IconButton>
              </InputAdornment>
            ),
          }}
        />
        <TextField
          className={styles.registerChild2}
          color="primary"
          id="password"
          label="Confirm password"
          required={true}
          sx={{ width: 237 }}
          variant="outlined"
          type={showPassword ? "text" : "password"}
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton
                  onClick={handleShowPasswordClick}
                  aria-label="toggle password visibility"
                >
                  <Icon>{showPassword ? "visibility_off" : "visibility"}</Icon>
                </IconButton>
              </InputAdornment>
            ),
          }}
        />
        <Button
          className={styles.rectangleButton}
          sx={{ width: 117 }}
          color="primary"
          variant="contained"
          href="/you"
        >
          Reister
        </Button>
      </div>
    </div>
  );
};

export default REGISTER;
