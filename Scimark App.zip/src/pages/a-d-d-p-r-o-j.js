import {
  TextField,
  InputAdornment,
  Icon,
  IconButton,
  Button,
} from "@mui/material";
import GroupComponent1 from "../components/group-component1";
import styles from "./a-d-d-p-r-o-j.module.css";

const ADDPROJ = () => {
  return (
    <div className={styles.addProj}>
      <div className={styles.addProject}>
        <img className={styles.image2Icon} alt="" src="/image-25@2x.png" />
        <b className={styles.enterYourProject}>Enter your project details...</b>
        <div className={styles.addProjectChild} />
        <b className={styles.uploadYourProject}>
          Upload your project pic above..
        </b>
        <TextField
          className={styles.addProjectItem}
          color="error"
          label="Enter your project name"
          sx={{ width: 237 }}
          variant="outlined"
        />
        <TextField
          className={styles.addProjectInner}
          color="primary"
          label="Write a small description about your project "
          sx={{ width: 237 }}
          variant="outlined"
          multiline
        />
        <TextField
          className={styles.rectangleTextfield}
          color="primary"
          label="Enter your project domain"
          sx={{ width: 237 }}
          variant="outlined"
        />
        <TextField
          className={styles.addProjectChild1}
          color="error"
          label="Enter cost of your project"
          sx={{ width: 237 }}
          variant="outlined"
        />
        <Button
          className={styles.rectangleButton}
          sx={{ width: 117 }}
          color="primary"
          variant="contained"
          href="/home"
        >
          Save
        </Button>
        <Button
          className={styles.addProjectChild2}
          sx={{ width: 117 }}
          color="primary"
          variant="contained"
          href="/you"
        >
          ADD+1
        </Button>
        <img
          className={styles.rectangleIcon}
          alt=""
          src="/Project pic@2x.png"
        />
        <input className={styles.rectangleInput} required={true} type="file" />
        <GroupComponent1 />
      </div>
    </div>
  );
};

export default ADDPROJ;
