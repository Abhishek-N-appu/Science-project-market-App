import { Button } from "@mui/material";
import GroupIcon from "../components/group-icon";
import GroupComponent5 from "../components/group-component5";
import styles from "./m-e-n-u.module.css";

const MENU = () => {
  return (
    <div className={styles.menu}>
      <div className={styles.menu1}>
        <img className={styles.image2Icon} alt="" src="/image-25@2x.png" />
        <b className={styles.menu2}>MENU..</b>
        <div className={styles.menuChild} />
        <b className={styles.hello}>Hello,</b>
        <Button
          className={styles.menuItem}
          sx={{ width: 329 }}
          color="primary"
          variant="contained"
          href="/cart"
        >
          Your orders
        </Button>
        <Button
          className={styles.menuInner}
          sx={{ width: 370 }}
          color="primary"
          variant="contained"
          href="/list"
        >
          Lists❤.
        </Button>
        <a className={styles.rectangleA} />
        <a className={styles.menuChild1} />
        <b className={styles.settings}>settings⚙</b>
        <b className={styles.customerCare}>customer care</b>
        <GroupIcon />
        <GroupComponent5
          vector="/vector13.svg"
          vector1="/vector14.svg"
          vector2="/vector15.svg"
          vector3="/vector16.svg"
          yOUHref="/you"
          yOUTop="90.43%"
          yOULeft="0%"
          yOUWidth="100%"
          yOUHeight="9.57%"
          yOURight="0%"
          yOUBottom="0%"
          propTop="65.31%"
          propCursor="pointer"
          propTextDecoration="none"
          propHeight="49.8%"
          propTop1="15.71%"
          propBottom="34.49%"
          propTop2="69.39%"
          propHeight1="31.43%"
          propTop3="23.98%"
          propBottom1="44.59%"
          propHeight2="47.14%"
          propTop4="15.71%"
          propBottom2="37.14%"
          propTop5="65.31%"
          propHeight3="49.8%"
          propTop6="14.59%"
          propBottom3="35.61%"
          propTop7="65.31%"
          propCursor1="pointer"
        />
      </div>
    </div>
  );
};

export default MENU;
