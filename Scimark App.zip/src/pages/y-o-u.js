import {
  TextField,
  InputAdornment,
  Icon,
  IconButton,
  Button,
} from "@mui/material";
import GroupComponent5 from "../components/group-component5";
import styles from "./y-o-u.module.css";

const YOU = () => {
  return (
    <div className={styles.you}>
      <div className={styles.you1}>
        <img className={styles.image2Icon} alt="" src="/image-27@2x.png" />
        <b className={styles.setUpYour}>Set up your profile..</b>
        <div className={styles.youChild} />
        <TextField
          className={styles.youItem}
          color="primary"
          label="Enter your full name"
          sx={{ width: 237 }}
          variant="outlined"
        />
        <TextField
          className={styles.youInner}
          color="primary"
          label="Domain of interest"
          sx={{ width: 237 }}
          variant="outlined"
        />
        <TextField
          className={styles.rectangleTextfield}
          color="primary"
          label="Enter your phone number"
          sx={{ width: 237 }}
          variant="outlined"
          type="tel"
        />
        <img className={styles.ellipseIcon} alt="" src="/profile pic@2x.png" />
        <TextField
          className={styles.youChild1}
          color="primary"
          label="Working as a"
          sx={{ width: 237 }}
          variant="outlined"
        />
        <Button
          className={styles.rectangleButton}
          sx={{ width: 117 }}
          color="primary"
          size="small"
          variant="contained"
          href="/home"
        >
          Save
        </Button>
        <Button
          className={styles.youChild2}
          sx={{ width: 117 }}
          color="primary"
          size="small"
          variant="contained"
          href="/add-proj"
        >
          Add project
        </Button>
        <div className={styles.uploadYourProfile}>
          Upload your profile pic..
        </div>
        <GroupComponent5
          vector="/vector13.svg"
          vector1="/vector14.svg"
          vector2="/vector15.svg"
          vector3="/vector16.svg"
        />
        <TextField
          className={styles.youChild3}
          color="primary"
          id="country"
          label="Country"
          sx={{ width: 237 }}
          variant="outlined"
        />
        <TextField
          className={styles.youChild4}
          color="primary"
          id="state"
          label="Provision/state"
          sx={{ width: 237 }}
          variant="outlined"
        />
        <TextField
          className={styles.youChild5}
          color="primary"
          label="Enter our skill set"
          sx={{ width: 237 }}
          variant="outlined"
        />
      </div>
    </div>
  );
};

export default YOU;
