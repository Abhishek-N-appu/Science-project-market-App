import { Link } from "react-router-dom";
import GroupIcon from "../components/group-icon";
import GroupComponent1 from "../components/group-component1";
import styles from "./h-o-m-e.module.css";

const HOME = () => {
  return (
    <div className={styles.home}>
      <div className={styles.homePage}>
        <img className={styles.image2Icon} alt="" src="/image-26@2x.png" />
        <Link className={styles.homePageChild} to="/earth-science" />
        <a className={styles.homePageItem} />
        <Link className={styles.earthScience} to="/earth-science">
          EARTH SCIENCE
        </Link>
        <GroupIcon />
        <Link className={styles.homePageInner} to="/space-science" />
        <Link className={styles.spaceScience} to="/space-science">
          SPACE SCIENCE
        </Link>
        <a className={styles.rectangleA} />
        <Link className={styles.homePageChild1} to="/material-science" />
        <Link className={styles.materialScience} to="/material-science">
          MATERIAL SCIENCE
        </Link>
        <Link className={styles.homePageChild2} to="/energy-and-env" />
        <Link
          className={styles.eneryAndEnvironmentalContainer}
          to="/energy-and-env"
        >
          <p className={styles.eneryAnd}>ENERY AND</p>
          <p className={styles.eneryAnd}> ENVIRONMENTAL</p>
        </Link>
        <a className={styles.homePageChild3} />
        <Link className={styles.homePageChild4} to="/others" />
        <img
          className={styles.rectangleIcon}
          alt=""
          src="/rectangle-15@2x.png"
        />
        <Link className={styles.others} to="/others">
          OTHERS
        </Link>
        <Link className={styles.homePageChild5} to="/life-science" />
        <a className={styles.homePageChild6} />
        <Link className={styles.lifeScience} to="/life-science">
          LIFE SCIENCE
        </Link>
        <Link className={styles.homePageChild7} to="/technology" />
        <Link className={styles.technology} to="/technology">
          TECHNOLOGY
        </Link>
        <a className={styles.homePageChild8} />
        <img
          className={styles.homePageChild9}
          alt=""
          src="/rectangle-27@2x.png"
        />
        <GroupComponent1 propTop7="2491px" />
        <div className={styles.rectangleParent}>
          <Link className={styles.groupChild} to="/find" />
          <Link className={styles.findSkilledPeople} to="/find">
            FIND SKILLED PEOPLE
          </Link>
          <img className={styles.groupItem} alt="" src="/ellipse-5@2x.png" />
        </div>
        <div className={styles.rectangleGroup}>
          <Link className={styles.groupInner} to="/group" />
          <Link className={styles.yourGroups} to="/group">
            YOUR GROUPS
          </Link>
          <img className={styles.ellipseIcon} alt="" src="/ellipse-4@2x.png" />
        </div>
      </div>
    </div>
  );
};

export default HOME;
