import { Button } from "@mui/material";
import GETPROJECTSATYOURDOORSTEP from "../components/g-e-t-p-r-o-j-e-c-t-s-a-t-y-o-u-r-d-o-o-r-s-t-e-p";
import styles from "./f-l-a-s-h.module.css";

const FLASH = () => {
  return (
    <div className={styles.flash}>
      <div className={styles.frame}>
        <img className={styles.image2Icon} alt="" src="/image-2@2x.png" />
        <img
          className={styles.undrawShoppingAppFlsj1Icon}
          alt=""
          src="/undraw-shopping-app-flsj-1.svg"
        />
        <div className={styles.theAppTo}>
          The app to make your open science project famous and help you to
          collaborate with other scientists.
        </div>
        <GETPROJECTSATYOURDOORSTEP />
        <Button
          className={styles.frameChild}
          sx={{ width: 208 }}
          color="primary"
          variant="contained"
          href="/register"
        >
          Get started
        </Button>
        <img className={styles.image3Icon} alt="" src="/image-3@2x.png" />
      </div>
    </div>
  );
};

export default FLASH;
