import LinkForm from "../components/link-form";
import GroupIcon from "../components/group-icon";
import GroupComponent5 from "../components/group-component5";
import styles from "./l-i-f-e-s-c-i-e-n-c-e.module.css";

const LIFESCIENCE = () => {
  return (
    <div className={styles.lifeScience}>
      <div className={styles.technology}>
        <img className={styles.image2Icon} alt="" src="/image-21@2x.png" />
        <b className={styles.lifeScience1}>LIFE SCIENCE</b>
        <LinkForm cOSTLeft="203px" cOSTTop="327px" xYZCursor="unset" />
        <GroupIcon />
        <div className={styles.technologyChild} />
        <LinkForm cOSTLeft="789px" cOSTTop="327px" xYZCursor="unset" />
        <LinkForm cOSTLeft="209px" cOSTTop="804px" xYZCursor="unset" />
        <LinkForm cOSTLeft="789px" cOSTTop="804px" xYZCursor="unset" />
      </div>
      <GroupComponent5
        vector="/vector.svg"
        vector1="/vector1.svg"
        vector2="/vector2.svg"
        vector3="/vector3.svg"
        yOUTop="92.25%"
        yOULeft="0%"
        yOUWidth="100%"
        yOUHeight="7.75%"
        yOURight="0%"
        yOUBottom="0%"
        propTop="65.34%"
        propCursor="pointer"
        propTextDecoration="none"
        propHeight="49.77%"
        propTop1="15.76%"
        propBottom="34.48%"
        propTop2="69.42%"
        propHeight1="31.42%"
        propTop3="23.91%"
        propBottom1="44.67%"
        propHeight2="47.17%"
        propTop4="15.76%"
        propBottom2="37.07%"
        propTop5="65.34%"
        propHeight3="49.77%"
        propTop6="14.55%"
        propBottom3="35.68%"
        propTop7="65.34%"
        propCursor1="unset"
      />
    </div>
  );
};

export default LIFESCIENCE;
