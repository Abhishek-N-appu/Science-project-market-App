import { Button } from "@mui/material";
import GroupComponent5 from "../components/group-component5";
import styles from "./a-f-t-e-r-p-a-y.module.css";

const AFTERPAY = () => {
  return (
    <div className={styles.afterPay}>
      <div className={styles.project}>
        <img className={styles.image2Icon} alt="" src="/image-22@2x.png" />
        <div className={styles.projectChild} />
        <div className={styles.projectItem} />
        <b className={styles.costxyz}>
          <span>COST</span>
          <span className={styles.xyz}>:XYZ</span>
        </b>
        <img
          className={styles.projectInner}
          alt="projet image"
          src="/rectangle-50@2x.png"
        />
        <b className={styles.projectName}>PROJECT NAME..</b>
        <b className={styles.detailedDescriptionOf}>
          DETAILED DESCRIPTION OF THE PROJECT WITHIN 500 WORDS.
        </b>
        <b className={styles.ownerOwnerName}>
          <span>owner</span>
          <span className={styles.xyz}>:-owner name</span>
        </b>
        <div className={styles.ellipseDiv} />
        <a className={styles.phone} href="tel:8884680318">
          <img className={styles.vectorIcon} alt="" src="/vector7.svg" />
        </a>
        <Button
          className={styles.rectangleButton}
          sx={{ width: 203 }}
          color="primary"
          variant="contained"
        >
          Dwnload DOCS
        </Button>
        <div className={styles.rectangleDiv} />
        <a className={styles.envelope} href="mailto:abhishekabhi0775@gmail.com">
          <img className={styles.vectorIcon1} alt="" src="/vector8.svg" />
        </a>
        <GroupComponent5
          vector="/vector.svg"
          vector1="/vector1.svg"
          vector2="/vector2.svg"
          vector3="/vector3.svg"
          yOUTop="92.25%"
          yOULeft="-0.07%"
          yOUWidth="100%"
          yOUHeight="7.75%"
          yOURight="0.07%"
          yOUBottom="0.01%"
          propTop="65.34%"
          propCursor="pointer"
          propTextDecoration="none"
          propHeight="49.77%"
          propTop1="15.76%"
          propBottom="34.48%"
          propTop2="69.42%"
          propHeight1="31.42%"
          propTop3="23.91%"
          propBottom1="44.67%"
          propHeight2="47.17%"
          propTop4="15.76%"
          propBottom2="37.07%"
          propTop5="65.34%"
          propHeight3="49.77%"
          propTop6="14.55%"
          propBottom3="35.68%"
          propTop7="65.34%"
          propCursor1="unset"
        />
      </div>
    </div>
  );
};

export default AFTERPAY;
