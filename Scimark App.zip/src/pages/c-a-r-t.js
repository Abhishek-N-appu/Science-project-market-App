import LinkCard from "../components/link-card";
import GroupIcon from "../components/group-icon";
import GroupComponent5 from "../components/group-component5";
import styles from "./c-a-r-t.module.css";

const CART = () => {
  return (
    <div className={styles.cart}>
      <div className={styles.cart1}>
        <img className={styles.image2Icon} alt="" src="/image-24@2x.png" />
        <div className={styles.cartChild} />
        <LinkCard />
        <b className={styles.yourPurchasesAppear}>
          Your purchases appear here..
        </b>
        <GroupIcon />
        <b className={styles.cart2}>CART..</b>
        <GroupComponent5
          vector="/vector.svg"
          vector1="/vector1.svg"
          vector2="/vector2.svg"
          vector3="/vector3.svg"
          yOUHref="/you"
          yOUTop="92.25%"
          yOULeft="0%"
          yOUWidth="100%"
          yOUHeight="7.75%"
          yOURight="0%"
          yOUBottom="0%"
          propTop="65.34%"
          propCursor="pointer"
          propTextDecoration="none"
          propHeight="49.77%"
          propTop1="15.76%"
          propBottom="34.48%"
          propTop2="69.42%"
          propHeight1="31.42%"
          propTop3="23.91%"
          propBottom1="44.67%"
          propHeight2="47.17%"
          propTop4="15.76%"
          propBottom2="37.07%"
          propTop5="65.34%"
          propHeight3="49.77%"
          propTop6="14.55%"
          propBottom3="35.68%"
          propTop7="65.34%"
          propCursor1="pointer"
        />
        <LinkCard cOSTLeft="235px" cOSTTop="337px" />
        <LinkCard cOSTLeft="235px" cOSTTop="837px" />
        <LinkCard cOSTLeft="901px" cOSTTop="837px" />
      </div>
    </div>
  );
};

export default CART;
