import styles from "./g-e-t-p-r-o-j-e-c-t-s-a-t-y-o-u-r-d-o-o-r-s-t-e-p.module.css";

const GETPROJECTSATYOURDOORSTEP = () => {
  return (
    <div className={styles.getProjectsAtYourDoorStep}>
      <b className={styles.getProjectsAt}>GET PROJECTS AT YOUR DOOR STEP</b>
    </div>
  );
};

export default GETPROJECTSATYOURDOORSTEP;
