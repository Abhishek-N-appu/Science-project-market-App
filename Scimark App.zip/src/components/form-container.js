import styles from "./form-container.module.css";

const FormContainer = () => {
  return (
    <div className={styles.rectangleParent}>
      <div className={styles.groupChild} />
      <b className={styles.amazon}>Amazon</b>
      <a
        className={styles.groupItem}
        href="https://bl-i.thgim.com/public/news/ylry0d/article66572690.ece/alternates/FREE_320/MicrosoftTeams-image.png"
      />
      <a className={styles.groupInner} />
      <b className={styles.paytm}>Paytm</b>
      <a
        className={styles.rectangleA}
        href="https://images.ctfassets.net/1nw4q0oohfju/5orczAiNhZlWpfSc1udRDv/73c35b34728ed63695962ecc12ffae5b/google-pay-sheet-web-payments-sdk.png"
      />
      <img className={styles.rectangleIcon} alt="" src="/rectangle-56@2x.png" />
      <b className={styles.gpay}>GPay</b>
      <b className={styles.phonepe}>PhonePe</b>
    </div>
  );
};

export default FormContainer;
