import styles from "./group-component6.module.css";

const GroupComponent6 = () => {
  return (
    <div className={styles.rectangleParent}>
      <div className={styles.componentChild} />
      <a
        className={styles.componentItem}
        href="https://science.gc.ca/site/science/en/citizen-science-portal"
      />
      <a
        className={styles.componentInner}
        href="https://www.nasa.gov/mission_pages/station/research/open_source_science_ops"
      />
      <a
        className={styles.rectangleA}
        href="https://science.nasa.gov/open-science-overview"
      />
      <a
        className={styles.openSourceOpportunities}
        href="https://www.nasa.gov/mission_pages/station/research/open_source_science_ops"
      >
        Open Source opportunities from the international Space Station
      </a>
      <a
        className={styles.governmentOfCanada}
        href="https://science.gc.ca/site/science/en/citizen-science-portal"
      >
        Government of Canada Citizen Science Portal
      </a>
      <div className={styles.moreResourcesWrapper}>
        <b className={styles.moreResources}>MORE RESOURCES:</b>
      </div>
      <a
        className={styles.learnAboutOpenSource}
        href="https://science.nasa.gov/open-science-overview"
      >
        Learn about Open-source science initiative
      </a>
      <a
        className={styles.componentChild1}
        href="https://www.citizenscience.gov/#"
      />
      <b className={styles.findCrowdsourcingProjects}>
        Find crowdsourcing projects
      </b>
    </div>
  );
};

export default GroupComponent6;
