import { useMemo } from "react";
import { Link } from "react-router-dom";
import styles from "./link-form.module.css";

const LinkForm = ({ emptyText, cOSTLeft, cOSTTop, xYZCursor }) => {
  const groupA1Style = useMemo(() => {
    return {
      left: cOSTLeft,
      top: cOSTTop,
    };
  }, [cOSTLeft, cOSTTop]);

  const rectangleAStyle = useMemo(() => {
    return {
      cursor: xYZCursor,
    };
  }, [xYZCursor]);

  return (
    <Link className={styles.rectangleParent} to="/project" style={groupA1Style}>
      <a className={styles.groupChild} style={rectangleAStyle} />
      <b className={styles.costxyz}>
        <span>COST</span>
        <span className={styles.xyz}>:XYZ</span>
      </b>
      <img className={styles.heartIcon} alt="" src="/heart.svg" />
      <div className={styles.groupItem} />
      <b className={styles.smallDescriptionIn}>
        Small description in less than 50 words
      </b>
      <b className={styles.projectName}>PROJECT NAME</b>
    </Link>
  );
};

export default LinkForm;
