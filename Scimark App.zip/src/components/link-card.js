import { useMemo } from "react";
import { Link } from "react-router-dom";
import styles from "./link-card.module.css";

const LinkCard = ({ cOSTLeft, cOSTTop }) => {
  const groupA2Style = useMemo(() => {
    return {
      left: cOSTLeft,
      top: cOSTTop,
    };
  }, [cOSTLeft, cOSTTop]);

  return (
    <Link className={styles.rectangleParent} to="/project" style={groupA2Style}>
      <a className={styles.groupChild} />
      <b className={styles.smallDescriptionIn}>
        Small description in less than 50 words
      </b>
      <b className={styles.costxyz}>
        <span>COST</span>
        <span className={styles.xyz}>:XYZ</span>
      </b>
      <b className={styles.projectName}>PROJECT NAME</b>
      <div className={styles.groupItem} />
    </Link>
  );
};

export default LinkCard;
