import { useMemo } from "react";
import GroupComponent5 from "./group-component5";
import styles from "./group-component1.module.css";

const GroupComponent1 = ({ propTop7 }) => {
  const groupDivStyle = useMemo(() => {
    return {
      top: propTop7,
    };
  }, [propTop7]);

  return (
    <div className={styles.addProjectInner} style={groupDivStyle}>
      <GroupComponent5
        vector="/vector13.svg"
        vector1="/vector14.svg"
        vector2="/vector15.svg"
        vector3="/vector16.svg"
        yOUHref="/you"
        yOUTop="0%"
        yOULeft="0%"
        yOUWidth="100%"
        yOUHeight="100%"
        yOURight="0%"
        yOUBottom="0%"
        propTop="65.31%"
        propCursor="pointer"
        propTextDecoration="none"
        propHeight="49.8%"
        propTop1="15.71%"
        propBottom="34.49%"
        propTop2="69.39%"
        propHeight1="31.43%"
        propTop3="23.98%"
        propBottom1="44.59%"
        propHeight2="47.14%"
        propTop4="15.71%"
        propBottom2="37.14%"
        propTop5="65.31%"
        propHeight3="49.8%"
        propTop6="14.59%"
        propBottom3="35.61%"
        propTop7="65.31%"
        propCursor1="pointer"
      />
    </div>
  );
};

export default GroupComponent1;
