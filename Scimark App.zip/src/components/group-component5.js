import { useMemo } from "react";
import { Link } from "react-router-dom";
import styles from "./group-component5.module.css";

const GroupComponent5 = ({
  vector,
  vector1,
  vector2,
  vector3,
  yOUHref,
  yOUTop,
  yOULeft,
  yOUWidth,
  yOUHeight,
  yOURight,
  yOUBottom,
  propTop,
  propCursor,
  propTextDecoration,
  propHeight,
  propTop1,
  propBottom,
  propTop2,
  propHeight1,
  propTop3,
  propBottom1,
  propHeight2,
  propTop4,
  propBottom2,
  propTop5,
  propHeight3,
  propTop6,
  propBottom3,
  propTop7,
  propCursor1,
}) => {
  const groupDiv1Style = useMemo(() => {
    return {
      top: yOUTop,
      left: yOULeft,
      width: yOUWidth,
      height: yOUHeight,
      right: yOURight,
      bottom: yOUBottom,
    };
  }, [yOUTop, yOULeft, yOUWidth, yOUHeight, yOURight, yOUBottom]);

  const mENUStyle = useMemo(() => {
    return {
      top: propTop,
    };
  }, [propTop]);

  const rectangleDivStyle = useMemo(() => {
    return {
      cursor: propCursor,
      textDecoration: propTextDecoration,
    };
  }, [propCursor, propTextDecoration]);

  const vectorIconStyle = useMemo(() => {
    return {
      height: propHeight,
      top: propTop1,
      bottom: propBottom,
    };
  }, [propHeight, propTop1, propBottom]);

  const hOMEStyle = useMemo(() => {
    return {
      top: propTop2,
    };
  }, [propTop2]);

  const vectorIcon1Style = useMemo(() => {
    return {
      height: propHeight1,
      top: propTop3,
      bottom: propBottom1,
    };
  }, [propHeight1, propTop3, propBottom1]);

  const vectorIcon2Style = useMemo(() => {
    return {
      height: propHeight2,
      top: propTop4,
      bottom: propBottom2,
    };
  }, [propHeight2, propTop4, propBottom2]);

  const cARTStyle = useMemo(() => {
    return {
      top: propTop5,
    };
  }, [propTop5]);

  const vectorIcon3Style = useMemo(() => {
    return {
      height: propHeight3,
      top: propTop6,
      bottom: propBottom3,
    };
  }, [propHeight3, propTop6, propBottom3]);

  const yOUStyle = useMemo(() => {
    return {
      top: propTop7,
      cursor: propCursor1,
    };
  }, [propTop7, propCursor1]);

  return (
    <div className={styles.rectangleParent} style={groupDiv1Style}>
      <div className={styles.componentChild} />
      <Link className={styles.componentItem} to="/home" />
      <Link className={styles.componentInner} to="/menu" />
      <Link className={styles.menu} to="/menu" style={mENUStyle}>
        MENU
      </Link>
      <Link className={styles.rectangleA} to="/cart" />
      <div className={styles.rectangleDiv} style={rectangleDivStyle} />
      <img
        className={styles.vectorIcon}
        alt=""
        src={vector}
        style={vectorIconStyle}
      />
      <Link className={styles.home} to="/home" style={hOMEStyle}>
        HOME
      </Link>
      <img
        className={styles.vectorIcon1}
        alt=""
        src={vector1}
        style={vectorIcon1Style}
      />
      <img
        className={styles.vectorIcon2}
        alt=""
        src={vector2}
        style={vectorIcon2Style}
      />
      <Link className={styles.cart} to="/cart" style={cARTStyle}>
        CART
      </Link>
      <img
        className={styles.vectorIcon3}
        alt=""
        src={vector3}
        style={vectorIcon3Style}
      />
      <a className={styles.you} style={yOUStyle}>
        YOU
      </a>
    </div>
  );
};

export default GroupComponent5;
