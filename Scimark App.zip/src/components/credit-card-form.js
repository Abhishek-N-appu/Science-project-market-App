import {
  Button,
  TextField,
  InputAdornment,
  Icon,
  IconButton,
} from "@mui/material";
import styles from "./credit-card-form.module.css";

const CreditCardForm = () => {
  return (
    <div className={styles.rectangleParent}>
      <div className={styles.groupChild} />
      <Button
        className={styles.groupItem}
        sx={{ width: 367.6 }}
        color="primary"
        size="small"
        variant="contained"
        href="/project"
      >
        Cancel
      </Button>
      <TextField
        className={styles.groupInner}
        color="primary"
        sx={{ width: 613.6 }}
        variant="outlined"
      />
      <b className={styles.cardNumber}>Card number</b>
      <b className={styles.cvv}>CVV</b>
      <TextField
        className={styles.rectangleTextfield}
        color="primary"
        sx={{ width: 969 }}
        variant="outlined"
      />
      <b className={styles.firstName}>First name</b>
      <TextField
        className={styles.groupChild1}
        color="primary"
        sx={{ width: 969 }}
        variant="outlined"
      />
      <b className={styles.lastName}>Last name</b>
      <b className={styles.validUntil}>Valid until</b>
      <TextField
        className={styles.groupChild2}
        color="primary"
        sx={{ width: 331.1 }}
        variant="outlined"
        type="date"
      />
      <Button
        className={styles.rectangleButton}
        sx={{ width: 379.7 }}
        color="primary"
        size="small"
        variant="contained"
      >
        Continue
      </Button>
      <img className={styles.rectangleIcon} alt="" src="/rectangle-68@2x.png" />
      <img className={styles.groupChild3} alt="" src="/rectangle-69@2x.png" />
      <img className={styles.groupChild4} alt="" src="/rectangle-70@2x.png" />
      <img className={styles.groupChild5} alt="" src="/rectangle-72@2x.png" />
      <img className={styles.groupChild6} alt="" src="/rectangle-73@2x.png" />
      <img className={styles.groupChild7} alt="" src="/rectangle-71@2x.png" />
      <TextField
        className={styles.groupChild8}
        color="primary"
        sx={{ width: 279.5 }}
        variant="outlined"
      />
    </div>
  );
};

export default CreditCardForm;
