import { useMemo } from "react";
import { Link } from "react-router-dom";
import styles from "./cost-link.module.css";

const CostLink = ({ cOSTLeft, cOSTTop }) => {
  const groupAStyle = useMemo(() => {
    return {
      left: cOSTLeft,
      top: cOSTTop,
    };
  }, [cOSTLeft, cOSTTop]);

  return (
    <Link className={styles.rectangleParent} to="/project" style={groupAStyle}>
      <a className={styles.groupChild} />
      <b className={styles.costxyz}>
        <span>COST</span>
        <span className={styles.xyz}>:XYZ</span>
      </b>
      <div className={styles.groupItem} />
      <b className={styles.smallDescriptionIn}>
        Small description in less than 50 words
      </b>
      <b className={styles.projectName}>PROJECT NAME</b>
    </Link>
  );
};

export default CostLink;
