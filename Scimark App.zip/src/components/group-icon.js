import styles from "./group-icon.module.css";

const GroupIcon = () => {
  return <img className={styles.homePageChild} alt="" src="/group-2.svg" />;
};

export default GroupIcon;
