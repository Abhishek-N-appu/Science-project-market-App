import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import FLASH from "./pages/f-l-a-s-h";
import FIND1 from "./pages/f-i-n-d1";
import GROUP from "./pages/g-r-o-u-p";
import LIST from "./pages/l-i-s-t";
import AFTERPAY from "./pages/a-f-t-e-r-p-a-y";
import PAYMENT from "./pages/p-a-y-m-e-n-t";
import PROJECT from "./pages/p-r-o-j-e-c-t";
import OTHERS from "./pages/o-t-h-e-r-s";
import MATERIALSCIENCE from "./pages/m-a-t-e-r-i-a-l-s-c-i-e-n-c-e";
import ENERGYANDENV from "./pages/e-n-e-r-g-y-a-n-d-e-n-v";
import SPACESCIENCE from "./pages/s-p-a-c-e-s-c-i-e-n-c-e";
import LIFESCIENCE from "./pages/l-i-f-e-s-c-i-e-n-c-e";
import EARTHSCIENCE from "./pages/e-a-r-t-h-s-c-i-e-n-c-e";
import TECHNOLOGY from "./pages/t-e-c-h-n-o-l-o-g-y";
import CART from "./pages/c-a-r-t";
import MENU from "./pages/m-e-n-u";
import HOME from "./pages/h-o-m-e";
import ADDPROJ from "./pages/a-d-d-p-r-o-j";
import YOU from "./pages/y-o-u";
import REGISTER from "./pages/r-e-g-i-s-t-e-r";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/find":
        title = "";
        metaDescription = "";
        break;
      case "/group":
        title = "";
        metaDescription = "";
        break;
      case "/list":
        title = "";
        metaDescription = "";
        break;
      case "/after-pay":
        title = "";
        metaDescription = "";
        break;
      case "/payment":
        title = "";
        metaDescription = "";
        break;
      case "/project":
        title = "";
        metaDescription = "";
        break;
      case "/others":
        title = "";
        metaDescription = "";
        break;
      case "/material-science":
        title = "";
        metaDescription = "";
        break;
      case "/energy-and-env":
        title = "";
        metaDescription = "";
        break;
      case "/space-science":
        title = "";
        metaDescription = "";
        break;
      case "/life-science":
        title = "";
        metaDescription = "";
        break;
      case "/earth-science":
        title = "";
        metaDescription = "";
        break;
      case "/technology":
        title = "";
        metaDescription = "";
        break;
      case "/cart":
        title = "";
        metaDescription = "";
        break;
      case "/menu":
        title = "";
        metaDescription = "";
        break;
      case "/home":
        title = "";
        metaDescription = "";
        break;
      case "/add-proj":
        title = "";
        metaDescription = "";
        break;
      case "/you":
        title = "";
        metaDescription = "";
        break;
      case "/register":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<FLASH />} />
      <Route path="/find" element={<FIND1 />} />
      <Route path="/group" element={<GROUP />} />
      <Route path="/list" element={<LIST />} />
      <Route path="/after-pay" element={<AFTERPAY />} />
      <Route path="/payment" element={<PAYMENT />} />
      <Route path="/project" element={<PROJECT />} />
      <Route path="/others" element={<OTHERS />} />
      <Route path="/material-science" element={<MATERIALSCIENCE />} />
      <Route path="/energy-and-env" element={<ENERGYANDENV />} />
      <Route path="/space-science" element={<SPACESCIENCE />} />
      <Route path="/life-science" element={<LIFESCIENCE />} />
      <Route path="/earth-science" element={<EARTHSCIENCE />} />
      <Route path="/technology" element={<TECHNOLOGY />} />
      <Route path="/cart" element={<CART />} />
      <Route path="/menu" element={<MENU />} />
      <Route path="/home" element={<HOME />} />
      <Route path="/add-proj" element={<ADDPROJ />} />
      <Route path="/you" element={<YOU />} />
      <Route path="/register" element={<REGISTER />} />
    </Routes>
  );
}
export default App;
